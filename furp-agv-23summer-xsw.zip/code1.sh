#! /bin/bash
cd ./src/Week1/src/helloworld
