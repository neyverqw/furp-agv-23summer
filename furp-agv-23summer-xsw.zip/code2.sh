#! /bin/bash
cd ./src/Week2/src/communication
