^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package mir_robot
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.1.7 (2023-01-20)
------------------

1.1.6 (2022-06-02)
------------------
* Rename mir_100 -> mir
  This is in preparation of mir_250 support.
* Contributors: Martin Günther

1.1.5 (2022-02-11)
------------------

1.1.4 (2021-12-10)
------------------

1.1.3 (2021-06-11)
------------------

1.1.2 (2021-05-12)
------------------

1.1.1 (2021-02-11)
------------------
* Contributors: Martin Günther

1.1.0 (2020-06-30)
------------------
* Initial release into noetic
* Contributors: Martin Günther

1.0.6 (2020-06-30)
------------------
* Set cmake_policy CMP0048 to fix warning
* Add sdc21x0 dependency to mir_robot meta package
* Contributors: Martin Günther

1.0.5 (2020-05-01)
------------------

1.0.4 (2019-05-06)
------------------

1.0.3 (2019-03-04)
------------------
* Add package: mir_dwb_critics
* Contributors: Martin Günther

1.0.2 (2018-07-30)
------------------
* Add metapackage
* Contributors: Martin Günther

1.0.1 (2018-07-17)
------------------

1.0.0 (2018-07-12)
------------------
