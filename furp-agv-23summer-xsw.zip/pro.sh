#! /bin/bash
cd ~/Desktop/git/furp-agv-23summer/
