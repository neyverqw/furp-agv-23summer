#! /bin/bash
cd ./src/Week3/src/
